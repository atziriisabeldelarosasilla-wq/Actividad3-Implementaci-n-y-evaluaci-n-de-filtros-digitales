"""
Actividad formativa 3. Implementacion y evaluacion de filtros digitales
-------------------------------------------------------------------------
Universidad Ciudadana de Nuevo Leon

Este script:
  1. Define una senal de entrada compuesta por varias frecuencias + ruido blanco.
  2. Disena filtros digitales pasa bajos, pasa altos y pasa banda,
     tanto IIR (Butterworth, Chebyshev tipo I) como FIR (metodo de ventana).
  3. Aplica cada filtro a la senal de prueba.
  4. Compara la senal antes y despues del filtrado (dominio del tiempo y
     dominio de la frecuencia) y grafica la respuesta en frecuencia de
     cada filtro.

Estructura recomendada que se sigue en el codigo:
  - Definicion de la senal de entrada
  - Diseno del filtro
  - Aplicacion del filtro a la senal
  - Visualizacion de los resultados

Requiere: numpy, scipy, matplotlib
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal
import os

# ---------------------------------------------------------------------------
# Configuracion general
# ---------------------------------------------------------------------------
FIG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figuras")
os.makedirs(FIG_DIR, exist_ok=True)

FS = 2000.0          # frecuencia de muestreo (Hz)
DURACION = 1.0        # duracion de la senal (s)
N = int(FS * DURACION)
t = np.linspace(0, DURACION, N, endpoint=False)

np.random.seed(7)     # reproducibilidad


def guardar(fig, nombre):
    """Guarda la figura en la carpeta /figuras y la cierra."""
    ruta = os.path.join(FIG_DIR, nombre)
    fig.tight_layout()
    fig.savefig(ruta, dpi=150)
    plt.close(fig)
    print(f"  -> figura guardada: figuras/{nombre}")


def espectro(x, fs):
    """Devuelve (frecuencias, magnitud) del espectro de amplitud de x (FFT)."""
    n = len(x)
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(n, d=1 / fs)
    mag = np.abs(X) / n * 2
    return f, mag


# ===========================================================================
# 1. DEFINICION DE LA SENAL DE ENTRADA
# ===========================================================================
print("1) Generando senales de prueba...")

# 1.1 Ruido blanco puro (para ilustrar su espectro plano)
ruido_blanco = np.random.normal(0, 1, N)

# 1.2 Senal compuesta: suma de tres tonos senoidales de baja, media y alta
#     frecuencia, contaminada con ruido blanco. Esta es la senal principal
#     que se usara para probar los tres tipos de filtro.
f_baja, f_media, f_alta = 20, 150, 450   # Hz
senal_limpia = (
    1.0 * np.sin(2 * np.pi * f_baja * t)
    + 0.8 * np.sin(2 * np.pi * f_media * t)
    + 0.6 * np.sin(2 * np.pi * f_alta * t)
)
senal_ruidosa = senal_limpia + 0.5 * np.random.normal(0, 1, N)

# --- Graficas de las senales ANTES del filtrado --------------------------
fig, axs = plt.subplots(2, 2, figsize=(11, 7))

axs[0, 0].plot(t[:400], ruido_blanco[:400], color="tab:gray", lw=0.8)
axs[0, 0].set_title("Ruido blanco (dominio del tiempo)")
axs[0, 0].set_xlabel("t (s)")
axs[0, 0].set_ylabel("Amplitud")

f_rb, mag_rb = espectro(ruido_blanco, FS)
axs[0, 1].plot(f_rb, mag_rb, color="tab:gray", lw=0.8)
axs[0, 1].set_title("Ruido blanco (espectro)")
axs[0, 1].set_xlabel("Frecuencia (Hz)")
axs[0, 1].set_ylabel("Magnitud")

axs[1, 0].plot(t[:400], senal_ruidosa[:400], color="tab:red", lw=0.9)
axs[1, 0].set_title(f"Senal compuesta ({f_baja}+{f_media}+{f_alta} Hz) + ruido")
axs[1, 0].set_xlabel("t (s)")
axs[1, 0].set_ylabel("Amplitud")

f_sr, mag_sr = espectro(senal_ruidosa, FS)
axs[1, 1].plot(f_sr, mag_sr, color="tab:red", lw=0.9)
axs[1, 1].set_title("Senal compuesta + ruido (espectro)")
axs[1, 1].set_xlabel("Frecuencia (Hz)")
axs[1, 1].set_ylabel("Magnitud")
axs[1, 1].set_xlim(0, FS / 2)

guardar(fig, "01_senales_entrada.png")


# ===========================================================================
# 2. DISENO DE LOS FILTROS
# ===========================================================================
print("2) Disenando filtros IIR (Butterworth, Chebyshev I) y FIR (ventana)...")

nyq = FS / 2

# --- 2.1 Pasa bajos: Butterworth IIR, orden 4, fc = 80 Hz -----------------
fc_lp = 80
b_lp_butter, a_lp_butter = signal.butter(4, fc_lp / nyq, btype="low")

# --- 2.2 Pasa altos: Chebyshev tipo I IIR, orden 4, fc = 250 Hz, 1 dB rizo -
fc_hp = 250
b_hp_cheby, a_hp_cheby = signal.cheby1(4, 1, fc_hp / nyq, btype="high")

# --- 2.3 Pasa banda: FIR con ventana de Hamming, banda 100-250 Hz ---------
fc_bp = [100, 250]
numtaps = 101
b_bp_fir = signal.firwin(numtaps, [f / nyq for f in fc_bp],
                          pass_zero=False, window="hamming")
a_bp_fir = [1.0]

filtros = {
    "Pasa bajos (Butterworth IIR, fc=80 Hz)": (b_lp_butter, a_lp_butter, "tab:blue"),
    "Pasa altos (Chebyshev I IIR, fc=250 Hz)": (b_hp_cheby, a_hp_cheby, "tab:green"),
    "Pasa banda (FIR ventana Hamming, 100-250 Hz)": (b_bp_fir, a_bp_fir, "tab:purple"),
}

# --- Grafica de la respuesta en frecuencia de cada filtro ------------------
fig, axs = plt.subplots(1, 3, figsize=(15, 4.2))
for ax, (nombre, (b, a, color)) in zip(axs, filtros.items()):
    w, h = signal.freqz(b, a, worN=2048, fs=FS)
    ax.plot(w, 20 * np.log10(np.maximum(np.abs(h), 1e-9)), color=color)
    ax.set_title(nombre, fontsize=9)
    ax.set_xlabel("Frecuencia (Hz)")
    ax.set_ylabel("Ganancia (dB)")
    ax.set_ylim(-80, 5)
    ax.axhline(-3, color="gray", ls="--", lw=0.8)
    ax.grid(alpha=0.3)
guardar(fig, "02_respuesta_frecuencia_filtros.png")


# ===========================================================================
# 3. APLICACION DE LOS FILTROS A LA SENAL
# ===========================================================================
print("3) Aplicando cada filtro a la senal ruidosa...")

salidas = {}
for nombre, (b, a, color) in filtros.items():
    y = signal.filtfilt(b, a, senal_ruidosa)   # fase cero (ida y vuelta)
    salidas[nombre] = (y, color)


# ===========================================================================
# 4. VISUALIZACION: COMPARACION ANTES / DESPUES
# ===========================================================================
print("4) Generando comparaciones antes/despues (tiempo y frecuencia)...")

for nombre, (y, color) in salidas.items():
    fig, axs = plt.subplots(2, 2, figsize=(11, 7))

    axs[0, 0].plot(t[:400], senal_ruidosa[:400], color="tab:red", lw=0.8)
    axs[0, 0].set_title("Antes del filtro (tiempo)")
    axs[0, 0].set_xlabel("t (s)")
    axs[0, 0].set_ylabel("Amplitud")

    axs[0, 1].plot(t[:400], y[:400], color=color, lw=0.9)
    axs[0, 1].set_title("Despues del filtro (tiempo)")
    axs[0, 1].set_xlabel("t (s)")
    axs[0, 1].set_ylabel("Amplitud")

    f1, m1 = espectro(senal_ruidosa, FS)
    axs[1, 0].plot(f1, m1, color="tab:red", lw=0.8)
    axs[1, 0].set_title("Antes del filtro (espectro)")
    axs[1, 0].set_xlabel("Frecuencia (Hz)")
    axs[1, 0].set_ylabel("Magnitud")
    axs[1, 0].set_xlim(0, FS / 2)

    f2, m2 = espectro(y, FS)
    axs[1, 1].plot(f2, m2, color=color, lw=0.9)
    axs[1, 1].set_title("Despues del filtro (espectro)")
    axs[1, 1].set_xlabel("Frecuencia (Hz)")
    axs[1, 1].set_ylabel("Magnitud")
    axs[1, 1].set_xlim(0, FS / 2)

    fig.suptitle(nombre, fontsize=11)
    slug = (
        nombre.split("(")[0].strip().lower()
        .replace(" ", "_").replace("á", "a")
    )
    guardar(fig, f"03_comparacion_{slug}.png")

# --- Grafica resumen: las 3 salidas superpuestas sobre la senal original --
fig, ax = plt.subplots(figsize=(11, 4.5))
ax.plot(t[:400], senal_ruidosa[:400], color="lightgray", lw=1.2, label="Senal original (con ruido)")
for nombre, (y, color) in salidas.items():
    etiqueta = nombre.split("(")[0].strip()
    ax.plot(t[:400], y[:400], color=color, lw=1.0, label=etiqueta)
ax.set_title("Resumen: senal original vs. salida de cada filtro")
ax.set_xlabel("t (s)")
ax.set_ylabel("Amplitud")
ax.legend(fontsize=8)
guardar(fig, "04_resumen_comparacion.png")

# ===========================================================================
# 5. METRICA DE EFECTIVIDAD: reduccion de energia de ruido fuera de banda
# ===========================================================================
print("5) Calculando metricas de efectividad de cada filtro...")

def energia(x):
    return float(np.sum(x ** 2))

e_entrada = energia(senal_ruidosa)
print(f"\n  Energia de la senal de entrada (ruidosa): {e_entrada:.2f}\n")
print(f"  {'Filtro':45s}{'Energia salida':>16s}{'Reduccion (%)':>16s}")
print("  " + "-" * 77)
resultados = []
for nombre, (y, color) in salidas.items():
    e_salida = energia(y)
    reduccion = 100 * (1 - e_salida / e_entrada)
    resultados.append((nombre, e_salida, reduccion))
    print(f"  {nombre:45s}{e_salida:16.2f}{reduccion:16.1f}")

print("\nListo. Todas las figuras se guardaron en la carpeta 'figuras/'.")
